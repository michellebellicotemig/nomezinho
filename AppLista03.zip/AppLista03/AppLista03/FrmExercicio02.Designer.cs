﻿namespace AppLista03
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.txtVlrPagar = new System.Windows.Forms.TextBox();
            this.lblVlrPagar = new System.Windows.Forms.Label();
            this.lblVlrLitro = new System.Windows.Forms.Label();
            this.txtVlrLitro = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTopo.SuspendLayout();
            this.pnlBase.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(70)))), ((int)(((byte)(83)))));
            this.pnlTopo.Controls.Add(this.lblTitulo);
            this.pnlTopo.Location = new System.Drawing.Point(-8, -1);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(578, 107);
            this.pnlTopo.TabIndex = 0;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Arial Narrow", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTitulo.Location = new System.Drawing.Point(20, 20);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(302, 75);
            this.lblTitulo.TabIndex = 2;
            this.lblTitulo.Text = "Exercicio02";
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(196)))), ((int)(((byte)(106)))));
            this.pnlBase.Controls.Add(this.lblResultado);
            this.pnlBase.Location = new System.Drawing.Point(-8, 355);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(578, 100);
            this.pnlBase.TabIndex = 1;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(26, 31);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(230, 37);
            this.lblResultado.TabIndex = 7;
            this.lblResultado.Text = "Resultado aqui";
            // 
            // txtVlrPagar
            // 
            this.txtVlrPagar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(157)))), ((int)(((byte)(143)))));
            this.txtVlrPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVlrPagar.Location = new System.Drawing.Point(332, 135);
            this.txtVlrPagar.Name = "txtVlrPagar";
            this.txtVlrPagar.Size = new System.Drawing.Size(174, 44);
            this.txtVlrPagar.TabIndex = 2;
            // 
            // lblVlrPagar
            // 
            this.lblVlrPagar.AutoSize = true;
            this.lblVlrPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrPagar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblVlrPagar.Location = new System.Drawing.Point(41, 142);
            this.lblVlrPagar.Name = "lblVlrPagar";
            this.lblVlrPagar.Size = new System.Drawing.Size(278, 37);
            this.lblVlrPagar.TabIndex = 3;
            this.lblVlrPagar.Text = "VALOR A PAGAR";
            // 
            // lblVlrLitro
            // 
            this.lblVlrLitro.AutoSize = true;
            this.lblVlrLitro.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrLitro.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblVlrLitro.Location = new System.Drawing.Point(41, 203);
            this.lblVlrLitro.Name = "lblVlrLitro";
            this.lblVlrLitro.Size = new System.Drawing.Size(285, 37);
            this.lblVlrLitro.TabIndex = 5;
            this.lblVlrLitro.Text = "VALOR DO LITRO";
            // 
            // txtVlrLitro
            // 
            this.txtVlrLitro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(157)))), ((int)(((byte)(143)))));
            this.txtVlrLitro.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVlrLitro.Location = new System.Drawing.Point(332, 203);
            this.txtVlrLitro.Name = "txtVlrLitro";
            this.txtVlrLitro.Size = new System.Drawing.Size(174, 44);
            this.txtVlrLitro.TabIndex = 4;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.btnCalcular.Location = new System.Drawing.Point(294, 269);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(212, 61);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(157)))), ((int)(((byte)(143)))));
            this.ClientSize = new System.Drawing.Size(568, 450);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblVlrLitro);
            this.Controls.Add(this.txtVlrLitro);
            this.Controls.Add(this.lblVlrPagar);
            this.Controls.Add(this.txtVlrPagar);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.pnlTopo);
            this.Name = "FrmExercicio02";
            this.Text = "FrmExercicio02";
            this.pnlTopo.ResumeLayout(false);
            this.pnlTopo.PerformLayout();
            this.pnlBase.ResumeLayout(false);
            this.pnlBase.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel pnlBase;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtVlrPagar;
        private System.Windows.Forms.Label lblVlrPagar;
        private System.Windows.Forms.Label lblVlrLitro;
        private System.Windows.Forms.TextBox txtVlrLitro;
        private System.Windows.Forms.Button btnCalcular;
    }
}